#!/bin/bash

sudo /bin/systemctl stop httpd.service
