#!/bin/bash

sudo /bin/systemctl start httpd.service
