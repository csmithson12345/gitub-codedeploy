#!/bin/bash

rm -f /var/www/html/index.html